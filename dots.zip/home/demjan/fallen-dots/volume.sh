#!/bin/sh

case "$1" in
    up)   pamixer -i 5 ;;
    down) pamixer -d 5 ;;
    mute) pamixer -t ;;
esac

VOLUME=$(pamixer --get-volume)
MUTED=$(pamixer --get-mute)

if [ "$MUTED" = "true" ]; then
    dunstify -a "OSD" -r 9993 -i audio-volume-muted " "
else
    if [ "$VOLUME" -lt 33 ]; then
        ICON="audio-volume-low"
    elif [ "$VOLUME" -lt 66 ]; then
        ICON="audio-volume-medium"
    else
        ICON="audio-volume-high"
    fi
    dunstify -a "OSD" -r 9993 -h int:value:"$VOLUME" -i "$ICON" " "
fi

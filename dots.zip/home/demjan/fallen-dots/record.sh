#!/bin/bash

OUTPUT_DIR="$HOME/Videos"
mkdir -p "$OUTPUT_DIR"

# Железная проверка: если pidof находит ffmpeg, то останавливаем его
if pidof ffmpeg > /dev/null; then
    pkill -2 -x "ffmpeg"
    notify-send "Запись экрана" "Запись успешно остановлена и сохранена!"
    exit 0
fi

# Если ffmpeg не запущен, генерируем имя файла и стартуем
FILENAME="$OUTPUT_DIR/rec_$(date +%Y-%m-%d_%H-%M-%S).mp4"

ffmpeg -f x11grab -video_size 1920x1080 -r 25 -i :0.0 \
       -c:v libx264 -preset ultrafast -crf 26 \
       "$FILENAME" > /tmp/ffmpeg_error.log 2>&1 &

notify-send "Запись экрана" "Запись запущена..."


#!/bin/bash

PID_FILE="/tmp/ffmpeg_stream.pid"
KEY_FILE="$HOME/.config/stream_key"

# Проверяем наличие ключа трансляции
if [ ! -f "$KEY_FILE" ]; then
    notify-send "Стрим" "Ошибка: Файл ~/.config/stream_key не найден!"
    exit 1
fi
STREAM_KEY=$(cat "$KEY_FILE")

# Настройки платформы (Раскомментируйте нужную и закомментируйте другую)
# Для Twitch:
RTMP_SERVER="rtmp://live.twitch.tv/app/$STREAM_KEY"
# Для YouTube:
# RTMP_SERVER="rtmp://://youtube.com"

# Если стрим уже идет — выключаем его
if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if ps -p "$PID" > /dev/null; then
        kill -2 "$PID"
        rm "$PID_FILE"
        notify-send -h string:x-dunst-stack-tag:stream "Стрим" "Трансляция успешно завершена."
        exit 0
    fi
fi

# Настройки для плавных 60 FPS на очень слабом ПК:
# -r 60             : задаем 60 кадров на входе
# scale=854:480     : снижаем разрешение до 480p, чтобы разгрузить процессор
# -g 120            : ключевой кадр каждые 2 секунды (требование Twitch/YouTube для 60fps)
# -b:v 1500k        : для 480p60 достаточно битрейта 1500k

ffmpeg -f x11grab -video_size 1920x1080 -r 60 -i :0.0 \
       -f pulse -i default \
       -vf "scale=854:480,format=yuv420p" \
       -c:v libx264 -preset ultrafast -pix_fmt yuv420p -g 120 -b:v 1500k \
       -c:a aac -b:a 128k -ar 44100 \
       -f flv "$RTMP_SERVER" > /dev/null 2>&1 &

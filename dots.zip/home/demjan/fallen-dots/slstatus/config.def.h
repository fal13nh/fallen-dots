/* See LICENSE file for copyright and license details. */

/* interval between updates (in milliseconds!) */
const unsigned int interval = 1000;

/* text to show if no value can be retrieved */
static const char unknown_str[] = "n/a";

/* maximum output string length */
#define MAXLEN 128

/*
 * Inside the argument string, %s indicates where the volatile string is placed.
 * You can add custom text, icons, or separators around it.
 */

static const struct arg args[] = {
	/* function     format          argument */

	/* 2. БЛЮТУЗ: Добавлен timeout, чтобы команда не блокировала панель */
	{ run_command,  "  %s | ",     "timeout 0.2 bluetoothctl show 2>/dev/null | grep -q 'Powered: yes' && echo 'ON' || echo 'OFF'" },

	/* 3. ИНТЕРНЕТ: Добавлен timeout */
	{ run_command,  "  %s | ",    "timeout 0.2 ip route get 1.1.1.1 2>/dev/null | awk '{print $5}' || echo 'Down'" },

        { keymap, "%s | ", NULL  },

        /* 5. БАТАРЕЯ */
        { run_command, "%s | ", "perc=$(cat /sys/class/power_supply/BAT*/capacity 2>/dev/null || echo 100); status=$(cat /sys/class/power_supply/BAT*/status 2>/dev/null); if [ \"$status\" = \"Charging\" ]; then icon=\" \"; else if [ \"$perc\" -ge 80 ]; then icon=\" \"; elif [ \"$perc\" -ge 60 ]; then icon=\" \"; elif [ \"$perc\" -ge 40 ]; then icon=\" \"; elif [ \"$perc\" -ge 20 ]; then icon=\" \"; else icon=\" \"; fi; fi; echo \"$icon $perc%\"" },

	/* 6. ВРЕМЯ: Исправленный формат */
	/* { run_command,  " %s",          " date +'%H:%M'" }, */
	{ datetime, "%s", "%H:%M" }


};
